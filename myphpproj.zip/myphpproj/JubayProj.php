<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mountain Climber Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:rgb(250, 248, 248);
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h1>Mountain Climber Management System</h1>

<div class="form-container">
    <form id="climberForm" onsubmit="submitForm(event)">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="mountain">Choose Mountain:</label>
        <select id="mountain" name="mountain" required>
            <option value="Mount Everest">Mount Everest</option>
            <option value="K2">K2</option>
            <option value="Kangchenjunga">Kangchenjunga</option>
            <option value="Lhotse">Lhotse</option>
            <option value="Makalu">Makalu</option>
            <option value="Cho Oyu">Cho Oyu</option>
            <option value="Dhaulagiri ">Dhaulagiri </option>
            <option value="Manaslu ">Manaslu </option>
            <option value="Nanga Parbat ">Nanga Parbat </option>
            <option value="Annapurna ">Annapurna </option>
        </select>

        <label for="code">Climber Code:</label>
        <input type="text" id="code" name="code" required>

        <button type="submit">Submit</button>
    </form>
</div>

<script>
    function submitForm(event) {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const mountain = document.getElementById('mountain').value;
        const code = document.getElementById('code').value;

        const formData = {
            name: name,
            email: email,
            mountain: mountain,
            code: code
        };

        fetch('submit_climber.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Climber information submitted successfully!');
                document.getElementById('climberForm').reset();
            } else {
                alert('There was an error submitting the form.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error submitting form.');
        });
    }
</script>

</body>
</html>
