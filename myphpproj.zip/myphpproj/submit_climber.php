<?php
// Database connection
$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "mountain_climbers"; // Database name

// create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the JavaScript fetch request
$data = json_decode(file_get_contents("php://input"), true);

// extract values from data
$name = $data['name'];
$email = $data['email'];
$mountain = $data['mountain'];
$code = $data['code'];

// insert data into MySQL database
$sql = "INSERT INTO climbers (name, email, mountain, code) VALUES ('$name', '$email', '$mountain', '$code')";

if ($conn->query($sql) === TRUE) {
    // send success response
    echo json_encode(["success" => true]);
} else {
    // send failure response
    echo json_encode(["success" => false, "error" => $conn->error]);
}

// close connection
$conn->close();
?>
